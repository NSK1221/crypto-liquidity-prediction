
# Diagrams & Visuals Summary

## 1. Feature Distributions
Visuals included in the EDA notebook: price trends, volume patterns, liquidity ratios.

## 2. Correlation Heatmap
Reveals how volume, price, and market cap relate to liquidity.

## 3. Model Evaluation
- MAE, RMSE, and R² plotted
- Residuals vs predicted chart (to be included in final notebook)

## 4. Architecture Diagram
Included in: `/docs/pipeline_architecture.md`
