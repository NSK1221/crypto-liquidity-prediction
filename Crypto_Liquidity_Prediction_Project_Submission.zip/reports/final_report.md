
# Cryptocurrency Liquidity Prediction for Market Stability

## 1. Project Objective
To build a machine learning model that predicts the liquidity score of cryptocurrencies based on historical pricing and volume data, enabling proactive risk management in crypto markets.

## 2. Data Sources
- **Files Used:** `coin_gecko_2022-03-16.csv`, `coin_gecko_2022-03-17.csv`
- **Features:** Price, % change, Volume, Market Cap, Date

## 3. Feature Engineering
- `daily_return` = (Close - Open) / Open
- `price_range` = High - Low
- `vol_to_mcap` = Volume / Market Cap
- `volatility_7d`, `volume_7d_avg` (rolling metrics)
- `day_of_week`, `month` from date

## 4. Modeling
- **Model:** Random Forest Regressor
- **Target Variable:** `liquidity_score` = vol_to_mcap × 100
- **Train/Test Split:** 80/20
- **Evaluation:**
  - MAE: 1.54
  - RMSE: 5.77
  - R² Score: 0.78

## 5. Deployment
- **Tool:** Streamlit
- **Features:**
  - Upload new CSVs
  - Predict and display liquidity score
  - Download predictions

## 6. Folder Structure
```
Crypto_Liquidity_Prediction/
│
├── data/
│   ├── raw/              # Raw input data
│   └── processed/        # Cleaned and transformed data
├── models/               # Trained ML model
├── deployment/
│   └── streamlit_app/    # Streamlit web app code
├── notebooks/            # EDA & modeling notebooks
├── scripts/              # Optional standalone scripts
└── reports/              # Documentation & results
```

## 7. Future Improvements
- Incorporate more time series modeling (LSTM)
- Improve handling of illiquid coins
- Add macroeconomic indicators or news sentiment

---
Prepared by: [Your Name]
Date: May 2025
