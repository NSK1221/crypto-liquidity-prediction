
# Pipeline Architecture

1. **Input**: Historical CSV files → /data/raw/
2. **Preprocessing**: Data cleaning, feature creation → /data/processed/
3. **Model Training**: Train model → /models/liquidity_model.pkl
4. **Deployment**: Streamlit app reads input → predicts → displays result

**Flow:**
CSV → Pandas + Feature Engineering → Scikit-learn Model → Streamlit App → Output Table
