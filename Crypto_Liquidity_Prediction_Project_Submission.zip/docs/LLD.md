
# Low-Level Design (LLD)

## Component Breakdown

### 1. Data Preprocessing
- Load raw CSV files
- Merge dataframes
- Convert `date` column
- Create features: `vol_to_mcap`, `day_of_week`, `month`

### 2. Feature Engineering
- Normalize volume to market cap
- Extract time features

### 3. Model Training
- Train-test split (80-20)
- Random Forest Regressor
- Save model using joblib

### 4. Streamlit App
- File uploader
- Load trained model
- Predict and show output in a table
