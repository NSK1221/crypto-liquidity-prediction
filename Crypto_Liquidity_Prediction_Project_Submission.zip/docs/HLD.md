
# High-Level Design (HLD)

## Objective
Predict cryptocurrency liquidity using historical price and volume data.

## Architecture Overview

1. **Data Collection**: CSV files from CoinGecko
2. **Data Preprocessing**: Cleaning, feature engineering (volatility, volume ratios)
3. **Model Training**: Random Forest Regressor trained on engineered features
4. **Evaluation**: RMSE, MAE, R²
5. **Deployment**: Streamlit web application for CSV upload and liquidity prediction

## Components
- Data Layer (CSV files)
- Processing Layer (Python scripts, Pandas, Scikit-learn)
- Model Layer (Random Forest)
- Interface Layer (Streamlit)
