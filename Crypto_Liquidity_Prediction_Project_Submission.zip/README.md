# 💸 Cryptocurrency Liquidity Prediction

## 📌 Project Overview
This project predicts the liquidity score of cryptocurrencies using machine learning based on CoinGecko data. It includes data preprocessing, EDA, feature engineering, model training, and deployment via Streamlit and Flask.

---

## 📁 Folder Structure
```
Crypto_Liquidity_Prediction/
├── data/                  # Raw and processed data
├── models/                # Trained ML models
├── notebooks/             # Jupyter notebooks (EDA, modeling)
├── deployment/            # Streamlit UI and Flask API
├── reports/               # Final report, architecture diagram
└── README.md              # GitHub overview (this file)
```

---

## 🛠️ How to Run

### 1. Clone Repository
```bash
git clone https://github.com/your-username/Crypto_Liquidity_Prediction.git
cd Crypto_Liquidity_Prediction
```

### 2. Install Requirements
```bash
pip install -r requirements.txt
```

### 3. Run the Streamlit App
```bash
cd deployment/streamlit_app
streamlit run app.py
```

### 4. Run the Flask API
```bash
python api.py
```

---

## 📊 Model Performance

| Metric | Value  |
|--------|--------|
| MAE    | 1.54   |
| RMSE   | 5.77   |
| R²     | 0.78   |

---

## 📄 Documents Included

- ✅ `EDA Report` – trends, insights, correlation
- ✅ `HLD & LLD` – architecture overview
- ✅ `Pipeline Diagram` – end-to-end flow
- ✅ `Final Report` – project summary, results

---

## 📦 Tech Stack
- Python, Pandas, Scikit-learn
- Streamlit, Flask
- Jupyter Notebooks
- Joblib for model persistence

---

## 👤 Author
**Your Name**  
[LinkedIn](https://linkedin.com/in/your-profile) | [GitHub](https://github.com/your-username)