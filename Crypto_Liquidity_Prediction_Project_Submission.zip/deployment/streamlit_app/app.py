
import streamlit as st
import pandas as pd
import joblib

# Load the trained model from the models folder
model = joblib.load('../models/liquidity_model.pkl')

# App Title
st.title("Cryptocurrency Liquidity Prediction")

# File uploader
uploaded_file = st.file_uploader("Upload your cryptocurrency data CSV", type="csv")

# Process uploaded file
if uploaded_file is not None:
    data = pd.read_csv(uploaded_file)
    st.write("### Uploaded Data Preview:", data.head())

    # Required columns for prediction
    required_columns = [
        'price_usd', 'change_1h', 'change_24h', 'change_7d',
        'volume_usd', 'market_cap_usd', 'day_of_week', 'month'
    ]

    # Check if all required columns are present
    if all(col in data.columns for col in required_columns):
        # Extract features and predict
        X = data[required_columns]
        predictions = model.predict(X)
        data['predicted_liquidity_score'] = predictions

        # Display predictions
        st.write("### Predictions:", data[['coin', 'predicted_liquidity_score']])

        # Allow user to download results
        st.download_button("Download Results", data.to_csv(index=False), "predictions.csv")
    else:
        st.warning("CSV missing required columns: {}".format(', '.join(required_columns)))
