
from flask import Flask, request, jsonify
import pandas as pd
import joblib

app = Flask(__name__)

# Load model
model = joblib.load('../../models/liquidity_model.pkl')

# Required columns
REQUIRED_COLS = ['price_usd', 'change_1h', 'change_24h', 'change_7d',
                 'volume_usd', 'market_cap_usd', 'day_of_week', 'month']

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        df = pd.DataFrame(data)
        if not all(col in df.columns for col in REQUIRED_COLS):
            return jsonify({'error': 'Missing one or more required columns.'}), 400

        predictions = model.predict(df[REQUIRED_COLS])
        df['predicted_liquidity_score'] = predictions
        return df.to_json(orient='records'), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
